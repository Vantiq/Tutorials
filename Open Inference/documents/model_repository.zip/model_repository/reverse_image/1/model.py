import numpy as np
import io
import triton_python_backend_utils as pb_utils
from PIL import Image

class TritonPythonModel:

    def initialize(self, args):
        self.logger = pb_utils.Logger

    def execute(self, requests):
        responses = []

        for request in requests:
            # --- Get Input Tensors ---
            self.logger.log_info("Executing reverse request.")
            in_image = pb_utils.get_input_tensor_by_name(request, "image")
            in_title = pb_utils.get_input_tensor_by_name(request, "title")

            image_bytes = in_image.as_numpy()[0]
            title_bytes = in_title.as_numpy()[0]
            title_string = title_bytes.decode('utf-8')
            self.logger.log_info(f"Received title: '{title_string}'")
            self.logger.log_info(f"Received image data of size: {len(image_bytes)} bytes")

            # --- Reverse the title string ---
            reversed_title_string = title_string[::-1]
            reversed_title_bytes = reversed_title_string.encode('utf-8')

            # --- Image Manipulation using Pillow ---
            img = Image.open(io.BytesIO(image_bytes))
            img = img.transpose(Image.FLIP_TOP_BOTTOM)
            img = img.transpose(Image.FLIP_LEFT_RIGHT)
            output_buffer = io.BytesIO()
            img_format = img.format if img.format else 'PNG'
            img.save(output_buffer, format=img_format)
            processed_image_bytes = output_buffer.getvalue()

            # --- Create Output Tensors ---
            out_image = pb_utils.Tensor(
                "output_image",
                np.array([processed_image_bytes], dtype=np.object_)
            )

            out_title = pb_utils.Tensor(
                "output_title",
                np.array([reversed_title_bytes], dtype=np.object_)
            )

            # --- Construct and Send Response ---
            inference_response = pb_utils.InferenceResponse(
                output_tensors=[out_image, out_title]
            )
            responses.append(inference_response)
            self.logger.log_info("Successfully processed request.")

        return responses

