import io
import numpy as np
from PIL import Image
import triton_python_backend_utils as pb_utils

class TritonPythonModel:
    """
    Performs manual preprocessing for a ViT model.
    """

    def initialize(self, args):
        # Define model-specific parameters manually
        self.image_size = (224, 224)
        self.mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        self.std = np.array([0.229, 0.224, 0.225], dtype=np.float32)

    def execute(self, requests):
        responses = []
        for request in requests:
            # Get raw image bytes
            raw_image_bytes = pb_utils.get_input_tensor_by_name(
                request, "RAW_IMAGE"
            ).as_numpy()[0]

            # Preprocess raw image bytes into a normalized, model-ready tensor.
            image = Image.open(io.BytesIO(raw_image_bytes)).convert("RGB")
            image = image.resize(self.image_size)
            image_np = np.array(image, dtype=np.float32) / 255.0
            normalized_np = (image_np - self.mean) / self.std
            transposed_np = normalized_np.transpose((2, 0, 1))
            output_tensor = pb_utils.Tensor("pixel_values", transposed_np)

            inference_response = pb_utils.InferenceResponse(
                output_tensors=[output_tensor]
            )
            responses.append(inference_response)

        return responses
