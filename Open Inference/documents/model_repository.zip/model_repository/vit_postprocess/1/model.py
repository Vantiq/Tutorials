import json
import numpy as np
import triton_python_backend_utils as pb_utils
import os

class TritonPythonModel:
    """
    This model takes raw logits, applies softmax, and returns a JSON string
    containing the top 3 class labels and their probabilities.
    """

    def initialize(self, args):
        # Load config.json and extract the label dictionary
        labels_path = os.path.join(args['model_repository'], args['model_version'], 'config.json')

        try:
            with open(labels_path, "r") as f:
                config_data = json.load(f)
                self.labels = config_data.get("id2label")
            if not self.labels:
                raise pb_utils.TritonModelException("Could not find 'id2label' key in the JSON file.")
        except Exception as e:
            raise pb_utils.TritonModelException(f"Failed to load or parse config file '{labels_path}'. Reason: {e}")

    def execute(self, requests):
        # Converts input logits to a JSON string with the top 3 labeled predictions.
        responses = []

        for request in requests:
            # Get the input tensor 'logits'
            logits_tensor = pb_utils.get_input_tensor_by_name(request, "logits")
            logits = logits_tensor.as_numpy().flatten()

            # Apply softmax to convert logits to probabilities, then get the top 3 predictions
            exp_logits = np.exp(logits - np.max(logits))
            probabilities = exp_logits / np.sum(exp_logits)

            top_3_indices = np.argsort(probabilities)[-3:][::-1]
            predictions = []
            for idx in top_3_indices:
                i = int(idx)  # Convert to Python int
                label = self.labels.get(str(i), f"class_{i}")
                prob = float(probabilities[i])

                predictions.append({
                    "label": label,
                    "probability": prob
                })

            output_string = json.dumps({"predictions": predictions})
            out_tensor = pb_utils.Tensor(
                "top_3_predictions",
                np.array([output_string], dtype=np.object_)
            )
            inference_response = pb_utils.InferenceResponse(output_tensors=[out_tensor])
            responses.append(inference_response)

        return responses
