import numpy as np
import triton_python_backend_utils as pb_utils

class TritonPythonModel:
    """
    A Triton Python backend model that calculates the dot product
    of a [3,1] tensor and a [1,3] tensor.
    """

    def execute(self, requests):
        responses = []

        for request in requests:
            in_0 = pb_utils.get_input_tensor_by_name(request, "first_input").as_numpy()
            in_1 = pb_utils.get_input_tensor_by_name(request, "second_input").as_numpy()

            dot_product_result = np.dot(in_0, in_1)

            out_tensor = pb_utils.Tensor(
                "result",
                dot_product_result.astype(np.float64)
            )

            inference_response = pb_utils.InferenceResponse(
                output_tensors=[out_tensor]
            )
            responses.append(inference_response)

        return responses

